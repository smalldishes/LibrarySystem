﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)

            SQLDao dao = new SQLDao();
            string sql = $"select count(*) from WeiGui where  status='锁定' ";

            SqlDataReader dc = dao.read(sql);
            int count = -1;
            while (dc.Read())
            {
                count=Convert.ToInt32(dc[0].ToString());
            }

            dc.Close();
            dao.Close();
            if (count>0)
            {
                label2.Visible=true;
                string sql2 = $"select name from WeiGui,students where students.library_card=WeiGui.library_card and status='锁定'";
                SqlDataReader dc2 = dao.read(sql2);
                while (dc2.Read())
                {
                    dataGridView1.Rows.Add(dc2[0].ToString()+"请求解锁", "去解锁");
                }

            }
            else
            {
                label2.Visible=false;
                dataGridView1.Visible=false;
            }
            
            
        }
        private void show()
        {
            
            
        }
        

        private void 修改密码ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.ShowDialog();
            this.Show();
        }

        private void 退出系统ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void 更新图书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            this.Hide();
            form7.ShowDialog();
            this.Show();
        }

        private void 查看图书信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            this.Hide();
            form6.ShowDialog();
            this.Show();
        }

        

        private void 借书记录查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form13 form13 = new Form13();
            this.Hide();
            form13.ShowDialog();
            this.Show();
        }

        private void 还书记录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form14 form14 = new Form14();
            this.Hide();
            form14.ShowDialog();
            this.Show();
        }

       

        private void 更新读者信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form12 form12 = new Form12();
            this.Hide();
            form12.ShowDialog();
            this.Show();
        }

        
        

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Columns[e.ColumnIndex].Name == "Column2" && e.Value != null &&e.Value.ToString()=="去解锁")
            {
                
                e.CellStyle.ForeColor = Color.Red;
                //将符合条件的行的Tag属性设置为该行的数据对象
                this.dataGridView1.Rows[e.RowIndex].Tag = "解锁";
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.dataGridView1.Columns[e.ColumnIndex].Name == "Column2"&& this.dataGridView1.Rows[e.RowIndex].Tag.Equals("解锁"))
            {
                Form16 form16 = new Form16();
                this.Hide();
                form16.ShowDialog();
                this.Show();
            }
        }

        private void 卡管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form16 form16 = new Form16();
            this.Hide();
            form16.ShowDialog();
            this.Show();
        }
    }
}
