﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

       

        private void 修改密码ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.ShowDialog();
            this.Show();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)

            show();
            
        }

        private void show()//显示学生主界面的学生基本信息
        {
            SQLDao dao = new SQLDao();
            name.Text=Data.username;
            string sql1 = $"select * from students where name='{Data.username}'";
            string sql2 = $"select overdue from students,WeiGui where students.library_card=WeiGui.library_card and name='{Data.username}'";
            SqlDataReader dc = dao.read(sql1);
            SqlDataReader dc2 = dao.read(sql2);
            while (dc.Read())
            {
                id.Text=dc["id"].ToString();
                bj.Text=dc["bj"].ToString();
                card.Text=dc["library_card"].ToString();
                borrow_count.Text=dc["borrow_count"].ToString();
            }
            while (dc2.Read())
            {

                overdue.Text=dc2["overdue"].ToString();
            }
            dao.Close();
        }

        private void 退出系统ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
            this.Show();
        }

        private void 图书查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            this.Hide();
            form6.ShowDialog();
            this.Show();
        }

        private void 借书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();
            this.Hide();
            form9.ShowDialog();
            this.Show();
        }

        private void 还书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form10 form10 = new Form10();
            this.Hide();
            form10.ShowDialog();
            this.Show();
        }

       

        private void Form3_Click(object sender, EventArgs e)
        {
            show();
        }

        private void 在读记录查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form11 form11 = new Form11();
            this.Hide();
            form11.ShowDialog();
            this.Show();
        }

        private void 借书记录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form15 form15 = new Form15();
            this.Hide();
            form15.ShowDialog();
            this.Show();
        }
    }
}
