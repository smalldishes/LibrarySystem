﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibrarySystem
{
    internal class SQLDao
    {
        SqlConnection conn;
        //数据库连接
        public SqlConnection connect()
        {
            string ConStr = "Data Source = DESKTOP-68HIP59\\SQLEXPRESS; Database = youran;"
    +"User Id = sa; Password = 20010418";
             conn = new SqlConnection(ConStr);
            conn.Open();
            return conn;
        }
        //获取command对象：执行sql语句
        public SqlCommand command(string sql)
        {
            SqlCommand cmd = new SqlCommand(sql, connect());
            return cmd;
        }
        //执行sql语句，并返回受影响的行数
        public int Excute(string sql)
        {
            return command(sql).ExecuteNonQuery();
        }
        //执行sql语句，并生成一个包含数据的 SqlDataReader对象的实例
        public SqlDataReader read(string sql)
        {
            return command(sql).ExecuteReader();
        }
        //关闭数据库
        public void Close()
        {
            conn.Close();
        }
    }
}
