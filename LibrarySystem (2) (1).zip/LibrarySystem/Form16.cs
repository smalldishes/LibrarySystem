﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)

            show();

        }
        private void show()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql1 = $"select name,WeiGui.library_card,status,overdue from students,WeiGui where WeiGui.library_card=students.library_card ";
            SqlDataReader dc = dao.read(sql1);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(),
                    dc[2].ToString(), dc[3].ToString());
            }
            dc.Close();
            dao.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SQLDao dao = new SQLDao();
            string sql = $"select * from WeiGui";
            SqlCommand command = dao.command(sql);
            //获取数据
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            //绑定数据到datagridview
            dataGridView1.DataSource=dt;
            dao.Close();
            show();
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string newValue = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            string columnname = dataGridView1.Columns[e.ColumnIndex].Name;

            string library_card = dataGridView1.Rows[e.RowIndex].Cells["library_card"].Value.ToString();


            // 执行更新语句
            SQLDao dao = new SQLDao();
            string updateSql = $"update students set {columnname} ='{newValue}' where library_card='{library_card}'";
            int n = dao.Excute(updateSql);
            if (n>0)
            {
                MessageBox.Show("修改成功！");
            }
            else
            {
                MessageBox.Show("修改失败！");
            }
            dao.Close();
        }

        private void dataGridView1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex==2&&e.FormattedValue!=null)
            {
                string value = e.FormattedValue.ToString();
                if (value.Equals("正常")||value.Equals("锁定"))
                {

                }
                else
                {
                    e.Cancel=true;
                    MessageBox.Show("只能输入“正常”或“锁定”！");
                }

            }

            if (e.ColumnIndex==3&&e.FormattedValue!=null)
            {
                int value;
                if (!int.TryParse(e.FormattedValue.ToString(), out value))
                {
                    e.Cancel=true;
                    MessageBox.Show("请输入整数！");
                }
            }

        }
    }
}
