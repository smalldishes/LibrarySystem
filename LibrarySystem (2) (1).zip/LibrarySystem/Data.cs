﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    internal class Data
    {
        public static string username = "",password="";
        public static string getLibCard(string username)
        {
            string library_card = "";
            SQLDao dao = new SQLDao();
            string sql1 = $"select library_card from students where name='{username}'";
            SqlDataReader dc = dao.read(sql1);
            while (dc.Read())
            {
                library_card=dc["library_card"].ToString();
            }
            dc.Close();
            dao.Close();

            return library_card;
        }
        

        //从数据库中读取全部数据显示在表格控件中
        public static void show_table(DataGridView dataGridView1)
        {
           dataGridView1.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql1 = $"select * from books";
            SqlDataReader dc = dao.read(sql1);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(),
                    dc[2].ToString(), dc[3].ToString(), dc[4].ToString(),
                    dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();
            dao.Close();
        }
    }
}
