﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string book_name = textBox1.Text;
            string book_id = textBox2.Text;
            string author = textBox3.Text;
            string price = textBox4.Text;
            int count = Convert.ToInt32(textBox5.Text);
            string publish = textBox6.Text;
            string type = textBox7.Text;

            SQLDao dao = new SQLDao();
            string sql = $"insert into books values('{book_name}','{book_id}','{author}'," +
                $"'{price}','{count}','{publish}','{type}')";
            int n=dao.Excute(sql);
            if (n>0)
            {
                MessageBox.Show("添加成功！");
            }
            else
            {
                MessageBox.Show("添加失败！");
            }
            foreach (Control ctr in Controls)   //遍历控件
            {
                if (ctr is TextBox)            //找到TextBox控件
                {
                    ((TextBox)ctr).Text = string.Empty;  //清空TextBox控件的文本内容

                }
            }
            dao.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            this.Hide();
            form7.ShowDialog();
            this.Show();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)
        }
    }
}
