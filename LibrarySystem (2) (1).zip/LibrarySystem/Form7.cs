﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace LibrarySystem
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            this.Hide();
            form8.ShowDialog();
            this.Show();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)
            Data.show_table(dataGridView1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Data.show_table(dataGridView1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SQLDao dao = new SQLDao();
            string sql = $"select * from books";
            SqlCommand command = dao.command(sql);
            //获取数据
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            //绑定数据到datagridview
            dataGridView1.DataSource=dt;
            dao.Close();

        }


        private void button3_Click(object sender, EventArgs e)
        {   //获取选中行的索引
            int rowToDelete = -1;
            foreach (DataGridViewRow selectedRow in dataGridView1.SelectedRows)
            {
                rowToDelete = selectedRow.Index;

            }
            if (rowToDelete<0)
            {
                MessageBox.Show("请选择书本删除！");
            }
            else
            {
                //获取要删除的行的书名
                string name = dataGridView1.Rows[rowToDelete].Cells[0].Value.ToString();
                MessageBoxButtons btn = MessageBoxButtons.YesNoCancel;
                if (MessageBox.Show("确定要删除么？", "删除数据", btn) == DialogResult.Yes)
                {
                    //从表中删除所选定的行
                    dataGridView1.Rows.RemoveAt(rowToDelete);
                    //更新数据库
                    SQLDao dao = new SQLDao();
                    string sql = $"delete from books where book_name='{name}'";
                    int n = dao.Excute(sql);
                    if (n>0)
                    {
                        MessageBox.Show("删除成功！");
                    }
                    else
                    {
                        MessageBox.Show("删除失败！");
                    }
                }
            }
            
           
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string newValue = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            string columnname=dataGridView1.Columns[e.ColumnIndex].Name;
           
            string bookid = dataGridView1.Rows[e.RowIndex].Cells["book_id"].Value.ToString();
            

            // 执行更新语句
            SQLDao dao = new SQLDao();
            string updateSql = $"update books set {columnname} ='{newValue}' where book_id='{bookid}'";
            int n=dao.Excute(updateSql);
            if (n>0)
            {
                MessageBox.Show("修改成功！");
            }
            else
            {
                MessageBox.Show("修改失败！");
            }
            dao.Close();
            
          
        }

        private void dataGridView1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {//检查价格栏的数据是否是浮点型数据，如果不是，就取消编辑
            
            if (e.ColumnIndex==1&&e.FormattedValue!=null)
            {
                string value = e.FormattedValue.ToString();
                if (!Regex.IsMatch(value, @"^\d{6}$"))
                {
                    e.Cancel=true;
                    MessageBox.Show("请输入6位纯数字组成的书号！");
                }
               
            }
            if (e.ColumnIndex==3&&e.FormattedValue!=null)
            {
                float value;
                if(!float.TryParse(e.FormattedValue.ToString(),out value))
                {
                    e.Cancel=true;
                    MessageBox.Show("请输入正确格式的价格（浮点数）！");
                }
            }
            if (e.ColumnIndex==4&&e.FormattedValue!=null)
            {
                int value;
                if (!int.TryParse(e.FormattedValue.ToString(), out value))
                {
                    e.Cancel=true;
                    MessageBox.Show("请输入正确格式的库存量(整数)！");
                }
            }
        }
    }
}
