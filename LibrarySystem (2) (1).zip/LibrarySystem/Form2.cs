﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace LibrarySystem
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string pwd = textBox2.Text;
            string check_pwd = textBox3.Text;
            if (name.Equals("") || pwd.Equals("") ||check_pwd.Equals(""))
            {
                MessageBox.Show("用户名或密码不能为空！");
            }
            else
            {
                if (pwd==check_pwd)
                {
                    SQLDao dao = new SQLDao();
                    //将注册信息放入数据库中
                    string addstr = "insert into users (name,password,identify) values ('"+name+"','"+pwd+"','学生')";
                    dao.Excute(addstr);
                    MessageBox.Show("注册成功！");
                    this.Close();
                    Form1 f1 = new Form1();
                    f1.Show();
                }
                else
                {
                    MessageBox.Show("两次输入的密码需一致，请重新输入！");
                    textBox2.Text="";
                    textBox3.Text="";
                }
            }

            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)
        }
    }
}
