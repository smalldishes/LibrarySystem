﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)

            SQLDao dao = new SQLDao();
            string sql = $"select count(*) from borrow_record where library_card='{Data.getLibCard(Data.username)}' and status='未归还'";

            SqlDataReader dc = dao.read(sql);
            int count = -1;
            while (dc.Read())
            {
                count=Convert.ToInt32(dc[0].ToString());
            }

            dc.Close();
            dao.Close();
            if (count>0)
            {
                pictureBox1.Visible=false;
                show();
            }
            else
            {
                dataGridView2.Visible=false;
            }
        }
        private void show()
        {
            dataGridView2.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql1 = $"select book_name,borrow_date,DATEDIFF(DAY,borrow_date,GETDATE()) as TimeDiff from books,borrow_record where borrow_record.book_id=books.book_id and status='未归还' and library_card='{Data.getLibCard(Data.username)}'";
            SqlDataReader dc = dao.read(sql1);
            while (dc.Read())
            {
                dataGridView2.Rows.Add(dc[0].ToString(),
                    dc[1].ToString(), dc[2].ToString()
                    );
            }
            dc.Close();
            dao.Close();
        }
        //如果借阅日期超过30天的记录标红
        private void dataGridView2_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView2.Columns[e.ColumnIndex].Name == "date_count" && e.Value != null &&Convert.ToInt64(e.Value.ToString()) >30)
            {
                e.CellStyle.ForeColor = Color.Red;
                //将符合条件的行的Tag属性设置为该行的数据对象
                this.dataGridView2.Rows[e.RowIndex].Tag = "超期";
            }
        }
        
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (this.dataGridView2.Columns[e.ColumnIndex].Name == "date_count"&& this.dataGridView2.Rows[e.RowIndex].Tag.Equals("超期"))
            {
                Form10 form10 = new Form10();
                this.Hide();
                form10.ShowDialog();
                this.Show();
            }
        }
    }
}
