﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form15 : Form
    {
        public Form15()
        {
            InitializeComponent();
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);
            //窗体的起始位置为(x,y)

            SQLDao dao = new SQLDao();
            string sql = $"select count(*) from borrow_record where library_card='{Data.getLibCard(Data.username)}' ";

            SqlDataReader dc = dao.read(sql);
            int count = -1;
            while (dc.Read())
            {
                count=Convert.ToInt32(dc[0].ToString());
            }

            dc.Close();
            dao.Close();
            if (count>0)
            {
                pictureBox1.Visible=false;
                show();
            }
            else
            {
                dataGridView1.Visible=false;
            }


        }

       private void show()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql1 = $"select book_name,borrow_date,status from borrow_record,books where borrow_record.book_id=books.book_id and library_card='{Data.getLibCard(Data.username)}'";
            SqlDataReader dc = dao.read(sql1);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(),
                    dc[2].ToString());
            }
            dc.Close();
            dao.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime start = dptStart.Value.Date;//Date属性将获取日期部分（年、月和日）并将时间部分重置为午夜
            DateTime end = dptEnd.Value.Date.AddDays(1).AddSeconds(-1);//保证匹配到所选的结束日期的最后一秒 
            // 遍历DataGridView的每一行
            foreach (DataGridViewRow row in dataGridView1.Rows){
                // 获取时间列的值
                DateTime time = Convert.ToDateTime(row.Cells["borrow_date"].Value);     
                // 判断时间是否在范围内
                if (time.Date >= start && time.Date <= end){
                    // 如果在范围内，将该行设置为可见
                    row.Visible = true;        
                }else
                {            // 否则将该行设置为不可见
                    row.Visible = false;        
                }   
            }

        }

        private void dptEnd_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
