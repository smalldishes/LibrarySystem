﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)
            seachAll();
        }
        private void seachAll()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql1 = $"select * from students ";
            SqlDataReader dc = dao.read(sql1);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(),
                    dc[2].ToString(), dc[3].ToString(), dc[4].ToString(),
                    dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();
            dao.Close();
        }

       

        private void button2_Click(object sender, EventArgs e)
        {
            //获取选中行的索引
            int rowToDelete = -1;
            foreach (DataGridViewRow selectedRow in dataGridView1.SelectedRows)
            {
                rowToDelete = selectedRow.Index;

            }
            if (rowToDelete<0)
            {
                MessageBox.Show("请选择学生删除！");
            }
            else
            {
                //获取要删除的行的书名
                string name = dataGridView1.Rows[rowToDelete].Cells[0].Value.ToString();

                MessageBoxButtons btn = MessageBoxButtons.YesNoCancel;
                if (MessageBox.Show("确定要删除么？", "删除数据", btn) == DialogResult.Yes)
                {
                    //从表中删除所选定的行
                    dataGridView1.Rows.RemoveAt(rowToDelete);
                    //更新数据库
                    SQLDao dao = new SQLDao();
                    string sql = $"delete from students where name='{name}'";
                    int n = dao.Excute(sql);
                    if (n>0)
                    {
                        MessageBox.Show("删除成功！");
                    }
                    else
                    {
                        MessageBox.Show("删除失败！");
                    }
                }
                seachAll();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SQLDao dao = new SQLDao();
            string sql = $"select * from students";
            SqlCommand command = dao.command(sql);
            //获取数据
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            //绑定数据到datagridview
            dataGridView1.DataSource=dt;
            dao.Close();
            seachAll();

        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string newValue = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            string columnname = dataGridView1.Columns[e.ColumnIndex].Name;
           
            string id = dataGridView1.Rows[e.RowIndex].Cells["id"].Value.ToString();
            

            // 执行更新语句
            SQLDao dao = new SQLDao();
            string updateSql = $"update students set {columnname} ='{newValue}' where id='{id}'";
            int n = dao.Excute(updateSql);
            if (n>0)
            {
                MessageBox.Show("修改成功！");
            }
            else
            {
                MessageBox.Show("修改失败！");
            }
            dao.Close();

        }

        private void dataGridView1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {   //校验学号
            if (e.ColumnIndex==1&&e.FormattedValue!=null)
            {
                string value = e.FormattedValue.ToString();
                if (!Regex.IsMatch(value, @"^\d{3}$"))
                {
                    e.Cancel=true;
                    MessageBox.Show("学号由3位纯数字组成！");
                }

            }
            //校验电话
            if (e.ColumnIndex==3&&e.FormattedValue!=null)
            {
                string value = e.FormattedValue.ToString();
                if (!Regex.IsMatch(value, @"^\d{11}$"))
                {
                    e.Cancel=true;
                    MessageBox.Show("请输入正确的电话格式！");
                }

            }
            //校验借书卡
            if (e.ColumnIndex==5&&e.FormattedValue!=null)
            {
                string value = e.FormattedValue.ToString();
                if (!Regex.IsMatch(value, @"^\d{4}$"))
                {
                    e.Cancel=true;
                    MessageBox.Show("借书卡号由4位纯数字组成！");
                }

            }

            


        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Columns[e.ColumnIndex].Name == "status" && e.Value != null &&e.Value.ToString()=="锁定")
            {
                e.CellStyle.ForeColor = Color.Red;
                //将符合条件的行的Tag属性设置为该行的数据对象
                this.dataGridView1.Rows[e.RowIndex].Tag = "状态";
            }
        }
    }
}
