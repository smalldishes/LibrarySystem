﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)

            dataGridView1.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql1 = $"select book_name,name,borrow_date,borrow_record.status from books,students,borrow_record " +
                $"where borrow_record.book_id=books.book_id and borrow_record.library_card=students.library_card";
            string sql2 = $"select book_name,count(*) as borrow_count  from borrow_record,books " +
                $"where borrow_record.book_id=books.book_id group by book_name order by borrow_count";
            SqlDataReader dc = dao.read(sql1);
            SqlDataReader dc1 = dao.read(sql2);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(),
                    dc[2].ToString(),  dc[3].ToString());
            }
            while (dc1.Read())
            {
                dataGridView2.Rows.Add(dc1[0].ToString(), dc1[1].ToString()
                    );
            }
            dc.Close();
            dao.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
