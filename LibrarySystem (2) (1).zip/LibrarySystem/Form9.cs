﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace LibrarySystem
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)
            seachAll();
        }
        //显示所有库存量大于0的图书信息
        private void seachAll()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql1 = $"select * from books where count>0";
            SqlDataReader dc = dao.read(sql1);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[1].ToString(), dc[0].ToString(),
                    dc[2].ToString(), dc[3].ToString(), dc[4].ToString(),
                    dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();
            dao.Close();
        }
        //借书按钮
        private void button1_Click(object sender, EventArgs e)
        {
            //获取选中行的索引
            int currentRowIndex = -1;
            foreach (DataGridViewRow selectedRow in dataGridView1.SelectedRows)
            {
                 currentRowIndex = selectedRow.Index;
               
            }
            if (currentRowIndex<0)
            {
                MessageBox.Show("请选择书本借阅！");
            }
            else
            {
                //获取book_id的值以便查询数据库
                string book_id = dataGridView1.Rows[currentRowIndex].Cells[0].Value.ToString();
               

                MessageBoxButtons btn = MessageBoxButtons.YesNoCancel;
                if (MessageBox.Show("确定要借阅么？", "借阅", btn) == DialogResult.Yes)
                {
                    //更新数据库
                    //1.检查用户借书卡是否处于正常状态
                    //2.检查用户的可借书本数是否大于0
                    //3.将记录插入borrow_book表
                    SQLDao dao = new SQLDao();
                    string sql1 = $"select status,students.library_card from students,WeiGui where students.library_card=WeiGui.library_card and name='{Data.username}'";
                    SqlDataReader dc = dao.read(sql1);
                    while (dc.Read())
                    {
                        string library_card = dc["library_card"].ToString();
                        if (dc["status"].ToString()=="正常")
                        {
                            string sql2 = $"select borrow_count from students where name='{Data.username}'";
                            dc=dao.read(sql2);
                            while (dc.Read())
                            {
                                if (Convert.ToInt32(dc["borrow_count"].ToString())>0)
                                {
                                    //用户借书量-1
                                    string sql3 = $"update students set borrow_count=borrow_count-1 where name='{Data.username}'";
                                    //借书记录插入数据库
                                    string sql4 = $"insert into borrow_record(book_id,library_card,borrow_date) values('{book_id}','{library_card}','{DateTime.Now.ToString()}')";
                                    //图书库存量-1
                                    string sql5 = $"update books set count=count-1 where book_id='{book_id}'";
                                    int count1 = dao.Excute(sql3);
                                    int count2 = dao.Excute(sql4);
                                    int count3 = dao.Excute(sql5);
                                    

                                    if (count1>0&&count2>0&&count3>0)
                                    {
                                        MessageBox.Show("借阅成功！");
                                        seachAll();
                                    }
                                    else
                                    {
                                        MessageBox.Show("借阅失败！");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("您的借书数量已达上限，请先还书！");
                                }
                            }
                        }
                        else if (dc["status"].ToString()=="锁定")
                        {
                            MessageBox.Show("无法借阅：您的借书卡已被锁定，请联系管理员解锁！");
                        }
                    }
                    dao.Close();
                }
            }
        }

        
    }
}
