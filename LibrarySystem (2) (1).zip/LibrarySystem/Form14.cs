﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)

            SQLDao dao = new SQLDao();
            string sql = $"select count(*) from return_record,borrow_record " +
                $"where return_record.library_card=borrow_record.library_card and status='已归还'";

            SqlDataReader dc = dao.read(sql);
            int count = -1;
            while (dc.Read())
            {
                count=Convert.ToInt32(dc[0].ToString());
            }

            dc.Close();
            dao.Close();
            if (count>0)
            {
                pictureBox1.Visible=false;
                show();
            }
            else
            {
                dataGridView1.Visible=false;
            }

        }
        private void show()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql1 = $"select students.name, books.book_name, borrow_record.borrow_date, return_record.return_date,datediff(day,borrow_date,return_date) as borrow_count " +
                $"from books,students,borrow_record,return_record " +
                $"where books.book_id=borrow_record.book_id and borrow_record.library_card = students.library_card " +
                $"and borrow_record.status='已归还' and borrow_record.book_id = return_record.book_id and borrow_record.library_card = return_record.library_card";
            SqlDataReader dc = dao.read(sql1);

            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[1].ToString(), dc[0].ToString(),
                    dc[2].ToString(), dc[3].ToString(), dc[4].ToString()
                    );
            }


            dc.Close();
            dao.Close();

        }
    }
}
