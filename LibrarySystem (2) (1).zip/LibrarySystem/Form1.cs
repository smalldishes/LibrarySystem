﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       

        private void Form1_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)
        }

        private void button3_Click(object sender, EventArgs e)//注册按钮，转到注册页面
        {

            Form2 f2 = new Form2();
            this.Hide();
            f2.ShowDialog();
            this.Show();

        }

        private void button1_Click(object sender, EventArgs e)//登录按钮
        {
            string name = username.Text;
            string pwd = password.Text;
            string type;
            if (radioButton1.Checked==true)
            {
                type=radioButton1.Text;
            }
            else
            {
                type=radioButton2.Text;
            }
           
            // 验证用户输入是否为空
            if (name.Equals("") || pwd.Equals("") )
            {
                MessageBox.Show("用户名或密码不能为空！");
            }
            // 验证用户名和密码是否与数据库匹配
            else
            {
                SQLDao dao = new SQLDao();
                
                if (type=="管理员")
                {
                    string sql1 = $"select * from users where name='{name}' and password='{pwd}' and identify='管理员'";
                    SqlDataReader dc = dao.read(sql1);
                    if (dc.Read())
                    {
                        Data.username=dc["name"].ToString();
                        Data.password=dc["password"].ToString();
                        MessageBox.Show("登陆成功！");
                        Form4 form4 = new Form4();
                        this.Hide();
                        form4.ShowDialog();
                        this.Show();
                    }
                    else
                    {
                        MessageBox.Show("登陆失败！");
                        username.Text="";
                        password.Text="";
                    }
                   
                }
                else if (type=="学生")
                {
                    string sql2 = $"select * from users where name='{name}' and password='{pwd}' and identify='学生'";
                    SqlDataReader dc = dao.read(sql2);
                    if (dc.Read())
                    {
                        Data.username=dc["name"].ToString();
                        Data.password=dc["password"].ToString();
                        MessageBox.Show("登陆成功！");
                        Form3 form3 = new Form3();
                        this.Hide();
                        form3.ShowDialog();
                        this.Show();
                    }
                    else
                    {
                        MessageBox.Show("登陆失败！");
                        username.Text="";
                        password.Text="";
                    }
                }
                dao.Close();//关闭数据库
            }
         }
    }
}
