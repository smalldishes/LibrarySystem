﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            this.Hide();
            form4.ShowDialog();
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string old_p = oldpwd.Text;
            string new_p=newpdw.Text;
            string check_p = checkpwd.Text;
            
            SQLDao dao = new SQLDao();
            string sql1 = $"select password from users where name='{Data.username}'";
            SqlDataReader dc = dao.read(sql1);
            if (dc.Read())
            {
                if (dc["password"].ToString()==old_p)
                {
                    if (new_p==check_p)
                    {
                        string sql2 = $"update users set password='{new_p}' where name='{Data.username}'";
                        dao.Excute(sql2);
                        MessageBox.Show("修改成功");
                    }
                    else
                    {
                        MessageBox.Show("两次密码输入不一致，请重新输入！");
                        newpdw.Text="";
                        checkpwd.Text="";
                    }
                }
                else
                {
                    MessageBox.Show("初始密码输入错误，请重新输入！");
                    oldpwd.Text="";
                }
            }
            dao.Close();
            

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)
        }
    }
}
