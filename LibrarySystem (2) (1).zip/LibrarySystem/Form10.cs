﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace LibrarySystem
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)

            SQLDao dao = new SQLDao();
            string sql = $"select count(*) from borrow_record where library_card='{Data.getLibCard(Data.username)}' and status='未归还'";
            
            SqlDataReader dc = dao.read(sql);
            int count = -1;
            while (dc.Read())
            {
                count=Convert.ToInt32(dc[0].ToString());
            }
            
            dc.Close();
            dao.Close();
            if (count>0)
            {
                pictureBox1.Visible=false;
                seachAll();
            }
            else
            {
                dataGridView1.Visible=false;
            }

        }
        private void seachAll()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql1 = $"select book_name,borrow_date from borrow_record,books where library_card='{Data.getLibCard(Data.username)}' and borrow_record.book_id=books.book_id and status='未归还'";
            SqlDataReader dc = dao.read(sql1);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString());
            }
            dc.Close();
            dao.Close();
        }
        //还书按钮
        private void button1_Click(object sender, EventArgs e)
        {
            //获取选中行的索引
            int currentRowIndex = -1;
            foreach (DataGridViewRow selectedRow in dataGridView1.SelectedRows)
            {
                currentRowIndex = selectedRow.Index;

            }
            if (currentRowIndex<0)
            {
                MessageBox.Show("请选择书本借阅！");
            }
            else
            {
                string book_name = dataGridView1.Rows[currentRowIndex].Cells[0].Value.ToString();
                return_book(book_name);
               
            }
        }
        //返回用户主界面按钮
        private void button3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            this.Hide();
            form3.ShowDialog();
            this.Show();
        }
        //还书具体操作
        private void return_book(string name)
        {
            SQLDao dao = new SQLDao();
            string sql1 = $"select book_id from books where book_name='{name}'";
            string sql2 = $"select library_card from students where name='{Data.username}'";
            SqlDataReader dc1 = dao.read(sql1);
            SqlDataReader dc2 = dao.read(sql2);
            string book_id="";
            string library_card = "";
            while (dc1.Read())
            {
                book_id=dc1["book_id"].ToString();
            }
            while (dc2.Read())
            {
                library_card=dc2["library_card"].ToString();
            }

            MessageBoxButtons btn = MessageBoxButtons.YesNoCancel;
            if (MessageBox.Show("确定要还书么？", "还书", btn) == DialogResult.Yes)
            {
                //将本条记录插入还书记录中
                
                string sql3 = $"insert into return_record(book_id,library_card,return_date) values('{book_id}','{library_card}','{DateTime.Now.ToString()}')";
                

                //学生的借书数量+1
                string sql4 = $"update students set borrow_count=borrow_count+1 where name='{Data.username}'";
                //图书的库存量+1
                string sql5 = $"update books set count=count+1 where book_name='{name}'";
                int count1 = dao.Excute(sql3);
                int count2 = dao.Excute(sql4);
                int count3 = dao.Excute(sql5);
               
               
                if (count1>0&&count2>0&&count3>0)
                {
                    MessageBox.Show("还书成功！");
                    //查看是否超期
                    string sql7 = $"select borrow_date from borrow_record where book_id='{book_id}' and library_card='{Data.getLibCard(Data.username)}'";
                    SqlDataReader dc7 = dao.read(sql7);
                    DateTime now = DateTime.Now;
                    DateTime borrowDate = now;
                    while (dc7.Read())
                    {
                        borrowDate = dc7.GetDateTime(0); // 获取 borrow_date 的值
                    }
                    //计算时间差
                    TimeSpan ts = now - borrowDate;
                    int result = (int)ts.TotalDays;
                    if (result>30)
                    {
                        string sql8 = $"update WeiGui set overdue=overdue+1 where library_card='{Data.getLibCard(Data.username)}'";
                        dao.Excute(sql8);
                    }
                    //修改状态
                    string sql6 = $"update  borrow_record set status='已归还' where book_id='{book_id}' and library_card='{Data.getLibCard(Data.username)}'";
                   dao.Excute(sql6);

                    seachAll();
                }
                else
                {
                    MessageBox.Show("还书失败！");
                }
                
                dao.Close();
            }
        }
        //续借按钮
        private void button2_Click(object sender, EventArgs e)
        {
            //获取选中行的索引
            int currentRowIndex = -1;
            foreach (DataGridViewRow selectedRow in dataGridView1.SelectedRows)
            {
                currentRowIndex = selectedRow.Index;
            }
            if (currentRowIndex<0)
            {
                MessageBox.Show("请选择书本续借！");
            }
            else
            {
                string name = dataGridView1.Rows[currentRowIndex].Cells[0].Value.ToString();

                //首先查看现在日期-借书日期是否大于30，若超过30天则不允许续借，必须要归还
                //若没有超过30天则允许续借
                SQLDao dao = new SQLDao();
                string sql = $"select book_id from books where book_name='{name}'";
                string book_id = "";
                SqlDataReader dc = dao.read(sql);
                while (dc.Read())
                {
                    book_id=dc["book_id"].ToString();
                }
                string sql1 = $"select borrow_date from borrow_record where book_id='{book_id}' and library_card='{Data.getLibCard(Data.username)}'";
                SqlDataReader dc1 = dao.read(sql1);
                DateTime now = DateTime.Now;
                DateTime borrowDate = now;
                while (dc1.Read())
                {
                    borrowDate = dc1.GetDateTime(0); // 获取 borrow_date 的值
                }

                TimeSpan ts = now - borrowDate;
                int result = (int)ts.TotalDays;
                if (result>30)
                {
                    MessageBox.Show("已超期，请还书");
                    return_book(name);
                  
                }
                else
                {
                    string sql2 = $"update borrow_record set borrow_date='{now.ToString()}' where book_id='{book_id}' and library_card='{Data.getLibCard(Data.username)}'";
                    int count1 = dao.Excute(sql2);
                    if (count1>0)
                    {
                        MessageBox.Show("续借成功！");
                        seachAll();
                    }
                    else
                    {
                        MessageBox.Show("续借失败！");
                    }

                }
                dao.Close();
            }

            
        }

        
    }
}
