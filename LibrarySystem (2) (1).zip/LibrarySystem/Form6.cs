﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            int x = (System.Windows.Forms.SystemInformation.WorkingArea.Width - this.Size.Width) / 2;
            int y = (System.Windows.Forms.SystemInformation.WorkingArea.Height - this.Size.Height) / 2;
            this.StartPosition = FormStartPosition.Manual; //窗体的位置由Location属性决定
            this.Location = (Point)new Size(x, y);         //窗体的起始位置为(x,y)
            Data.show_table(dataGridView1);
        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            string condition = search.Text;
            string key = keys.Text;
            dataGridView1.Rows.Clear();//清空旧数据
            SQLDao dao = new SQLDao();
            string sql="";
            if (condition=="书名")
            {
                 sql = $"select * from books where book_name='{key}'";
               
            }else if (condition=="书号")
            {
                sql = $"select * from books where book_id='{key}'";
               
            }else if (condition=="类型")
            {
                sql = $"select * from books where type='{key}'";
               
            }
            SqlDataReader dc = dao.read(sql);

            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(),
                   dc[2].ToString(), dc[3].ToString(), dc[4].ToString(),
                   dc[5].ToString(), dc[6].ToString());
            }
            dc.Close();
            dao.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Data.show_table(dataGridView1);
        }

        private void dataGridView1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            e.Cancel=true;//当用户尝试编辑单元格时，
                          //CellBeginEdit事件将被触发并且自动取消编辑操作。这将使用户无法编辑任何单元格。
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
